# MIL2019-方楠-实验二代码与报告

## 文件夹内容说明

### Friday Report

这是我周五下午报告的全部内容，包括原始的 notebook 文件，图片和导出的 html 文件。

可以将，这两个 html 文件上传到暑期班的网站上，暑期班网站上的展示名就是这两个文件的文件名。
- Naive Bayes
- Using Naive-Bayes Classifier on MNIST

### Paper Implementation

这是我的论文复现作业，在这个作业中有我对于 KMeans 算法的数学公式简化，完全使用矩阵运算来完成 KMeans 聚类算法任务。

可以对其放到暑期班网站上进行展示，展示名就用文件名。

由于时间限制，我还没有跑完这个代码，但是我觉得大体的思路和对于论文的解析和公式的推导应该没有什么问题。

### Hand Write & Use Sciket-Learn Navie Bayes Classifier PCA  Kmeans Clustering on MNIST

这是初稿的 Navie Bayes, PCA, KMeans 的手写源码实现，没有时间修改，性能比较菜。
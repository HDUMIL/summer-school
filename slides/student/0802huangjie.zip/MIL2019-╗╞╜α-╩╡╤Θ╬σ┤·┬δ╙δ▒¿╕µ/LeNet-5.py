import torch
import torchvision as tv
import torchvision.transforms as transforms
import torch.nn as nn
import torch.optim as optim

# 定义是否使用GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 定义网络结构
class LeNet5(nn.Module):
    def __init__(self):
        super(LeNet5, self).__init__()  # super用法:LeNet5继承父类nn.Model的属性，并用父类的方法初始化这些属性
        #  nn.Sequential()：一个时序容器。Modules 会以他们传入的顺序被添加到容器中。这个容器里可以初始化卷积层、激活层和池化层。
        self.conv1 = nn.Sequential(     # input_size=(1*28*28)
            nn.Conv2d(1, 20, 5, 1),
            # input_size=(20*24*24)
            nn.MaxPool2d(kernel_size=2, stride=2),  # output_size=(20*12*12)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(20, 50, 5),
            # input_size=(50*8*8)
            nn.MaxPool2d(2, 2)  # output_size=(50*4*4)
        )
        self.fc1 = nn.Sequential(
            nn.Linear(50 * 4 * 4, 500),  # 全连接层
            nn.ReLU()
        )
        self.fc2 = nn.Linear(500, 10)

    # 定义前向传播过程，输入为x
    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        # nn.Linear()的输入输出都是维度为一的值，所以要把多维度的tensor展平成一维
        x = x.view(x.size()[0], -1)
        x = self.fc1(x)
        x = self.fc2(x)
        # x = self.fc3(x)
        return x

# 超参数设置
EPOCH = 8  # 遍历训练整个数据集的次数
BATCH_SIZE = 60      # 批处理尺寸(batch_size),指将数据集分成n个batch(批)，每一个batch的大小
LR = 0.001        # 学习率

# 定义数据预处理方式
transform = transforms.ToTensor()

# 定义训练数据集
trainset = tv.datasets.MNIST(
    root='./data/',
    train=True,  # train=True表示训练集，train=False表示测试集
    download=True,
    transform=transform
)

# 定义训练批处理数据
# 数据加载器。组合数据集和采样器，并在数据集上提供单进程或多进程迭代器
trainloader = torch.utils.data.DataLoader(
    trainset,
    batch_size=BATCH_SIZE,  # 每个batch加载多少个样本
    shuffle=True,  # 设置为True时会在每个epoch重新打乱数据(默认: False)
)

# 定义测试数据集
testset = tv.datasets.MNIST(
    root='./data/',
    train=False,
    download=True,
    transform=transform
)

# 定义测试批处理数据
testloader = torch.utils.data.DataLoader(
    testset,
    batch_size=BATCH_SIZE,
    shuffle=False,
)

# 定义损失函数loss function 和优化方式（采用SGD）
net = LeNet5().to(device)
criterion = nn.CrossEntropyLoss()  # 针对单目标分类问题, 结合了 nn.LogSoftmax() 和 nn.NLLLoss() 来计算 loss.
optimizer = optim.SGD(net.parameters(), lr=LR, momentum=0.9)  # 优化器，设置学习的速度和使用的模型

# 训练
if __name__ == "__main__":

    for epoch in range(EPOCH):
        sum_loss = 0.0
        # 数据读取
        for i, data in enumerate(trainloader):
            inputs, labels = data
            inputs, labels = inputs.to(device), labels.to(device)

            # 梯度清零，也就是把loss关于weight的导数变成0.
            optimizer.zero_grad()

            # 向后传播
            outputs = net(inputs)  # 网络的前向传播
            loss = criterion(outputs, labels)  # 将输出的outputs和原来导入的labels作为loss函数的输入，得到损失
            loss.backward()  # 计算得到loss后回传损失
            optimizer.step()  # 回传损失过程中会计算梯度，然后需要根据这些梯度更新参数，optimizer.step()就是用来更新参数的,进行单次优化

            # 每训练100个batch打印一次平均loss
            sum_loss += loss.item()
            if i % 100 == 99:
                print('[%d, %d] loss: %.03f'
                      % (epoch + 1, i + 1, sum_loss / 100))
                sum_loss = 0.0

        # 测试这个模型，每遍历一次测试一下准确率
        with torch.no_grad():
            correct = 0
            total = 0
            for data in testloader:
                images, labels = data
                images, labels = images.to(device), labels.to(device)
                outputs = net(images)
                # 取得分最高的那个类
                _, predicted = torch.max(outputs.data, 1)  # 预测最大值所在的位置标签，即预测的数字
                total += labels.size(0)
                correct += (predicted == labels).sum()
            print('第%d次遍历的识别准确率为：%d%%' % (epoch + 1, (100 * correct / total)))
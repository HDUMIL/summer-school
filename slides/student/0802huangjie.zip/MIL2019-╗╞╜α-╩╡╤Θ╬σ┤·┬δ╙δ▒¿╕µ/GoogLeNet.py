import numpy as np
import torch
import torch.nn as nn
import torchvision as tv
import torchvision.transforms as transforms
import torch.optim as optim

# 定义是否使用GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def conv_relu(in_channel,out_channel,kernel,stride=1,padding=0):
    layer = nn.Sequential(
        nn.Conv2d(in_channel,out_channel,kernel,stride,padding),
        nn.BatchNorm2d(out_channel,eps=1e-3),  # 批归一化处理
        nn.ReLU(True)
    )
    return layer


# 定义一个inception模块类
class inception(nn.Module):
    def __init__(self,in_channel,out1_1,out2_1,out2_3,out3_1,out3_5,out4_1):
        super(inception,self).__init__()
        self.branch1x1 = conv_relu(in_channel,out1_1,1)

        self.branch3x3 = nn.Sequential(
            conv_relu(in_channel,out2_1,1),
            conv_relu(out2_1,out2_3,3,padding=1)
        )

        self.branch5x5 = nn.Sequential(
            conv_relu(in_channel,out3_1,1),
            conv_relu(out3_1,out3_5,5,padding=2),
        )

        self.branch_pool = nn.Sequential(
            nn.MaxPool2d(3,stride=1,padding=1),
            conv_relu(in_channel,out4_1,1),
        )

    def forward(self, x):
        f1 = self.branch1x1(x)
        f2 = self.branch3x3(x)
        f3 = self.branch5x5(x)
        f4 = self.branch_pool(x)

        output = torch.cat((f1,f2,f3,f4),dim=1)

        return output


# 定义GoogleNet类，让很多inception串联起来
class GoogleNet(nn.Module):
    def __init__(self,in_channel,num_classes):
        super(GoogleNet,self).__init__()

        self.block1 = nn.Sequential(
            conv_relu(in_channel,out_channel=64,kernel=7,stride=2,padding=37),
            nn.MaxPool2d(3,2)
        )

        self.block2 = nn.Sequential(
            conv_relu(64,64,kernel=1),
            conv_relu(64,192,kernel=3,padding=1),
            nn.MaxPool2d(3,2)
        )

        self.block3 = nn.Sequential(
            inception(192, 64, 96, 128, 16, 32, 32),
            inception(256, 128, 128, 192, 32, 96, 64),
            nn.MaxPool2d(3, 2)
        )

        self.block4 = nn.Sequential(
            inception(480, 192, 96, 208, 16, 48, 64),
            inception(512, 160, 112, 224, 24, 64, 64),
            inception(512, 128, 128, 256, 24, 64, 64),
            inception(512, 112, 144, 288, 32, 64, 64),
            inception(528, 256, 160, 320, 32, 128, 128),
            nn.MaxPool2d(3, 2)
        )

        self.block5 = nn.Sequential(
            inception(832, 256, 160, 320, 32, 128, 128),
            inception(832, 384, 182, 384, 48, 128, 128),
            nn.AvgPool2d(2)
        )

        self.classifier = nn.Linear(1024,num_classes)

    def forward(self, x):
        x = self.block1(x)
        x = self.block2(x)
        x = self.block3(x)
        x = self.block4(x)
        x = self.block5(x)
        x = x.view(x.shape[0],-1)
        x = self.classifier(x)
        return x

# 超参数设置
EPOCH = 8  # 遍历训练整个数据集的次数
BATCH_SIZE = 60      # 批处理尺寸(batch_size),指将数据集分成n个batch(批)，每一个batch的大小
LR = 0.001        # 学习率

# 定义数据预处理方式
transform = transforms.ToTensor()

# 定义训练数据集
trainset = tv.datasets.MNIST(
    root='./data/',
    train=True,  # train=True表示训练集，train=False表示测试集
    download=True,
    transform=transform
)

# 定义训练批处理数据
# 数据加载器。组合数据集和采样器，并在数据集上提供单进程或多进程迭代器
trainloader = torch.utils.data.DataLoader(
    trainset,
    batch_size=BATCH_SIZE,  # 每个batch加载多少个样本
    shuffle=True,  # 设置为True时会在每个epoch重新打乱数据(默认: False)
)

# 定义测试数据集
testset = tv.datasets.MNIST(
    root='./data/',
    train=False,
    download=True,
    transform=transform
)

# 定义测试批处理数据
testloader = torch.utils.data.DataLoader(
    testset,
    batch_size=BATCH_SIZE,
    shuffle=False,
)

# 定义损失函数loss function 和优化方式（采用SGD）
net = GoogleNet(1,10).to(device)
criterion = nn.CrossEntropyLoss()  # 针对单目标分类问题, 结合了 nn.LogSoftmax() 和 nn.NLLLoss() 来计算 loss.
optimizer = optim.SGD(net.parameters(), lr=LR, momentum=0.9)  # 优化器，设置学习的速度和使用的模型

# 训练
if __name__ == "__main__":

    for epoch in range(EPOCH):
        sum_loss = 0.0
        # 数据读取
        for i, data in enumerate(trainloader):
            inputs, labels = data
            inputs, labels = inputs.to(device), labels.to(device)

            # 梯度清零，也就是把loss关于weight的导数变成0.
            optimizer.zero_grad()

            # 向后传播
            outputs = net(inputs)  # 网络的前向传播
            loss = criterion(outputs, labels)  # 将输出的outputs和原来导入的labels作为loss函数的输入，得到损失
            loss.backward()  # 计算得到loss后回传损失
            optimizer.step()  # 回传损失过程中会计算梯度，然后需要根据这些梯度更新参数，optimizer.step()就是用来更新参数的,进行单次优化

            # 每训练100个batch打印一次平均loss
            sum_loss += loss.item()
            if i % 100 == 99:
                print('[%d, %d] loss: %.03f'
                      % (epoch + 1, i + 1, sum_loss / 100))
                sum_loss = 0.0

        # 测试这个模型，每遍历一次测试一下准确率
        with torch.no_grad():
            correct = 0
            total = 0
            for data in testloader:
                images, labels = data
                images, labels = images.to(device), labels.to(device)
                outputs = net(images)
                # 取得分最高的那个类
                _, predicted = torch.max(outputs.data, 1)  # 预测最大值所在的位置标签，即预测的数字
                total += labels.size(0)
                correct += (predicted == labels).sum()
            print('第%d次遍历的识别准确率为：%d%%' % (epoch + 1, (100 * correct / total)))
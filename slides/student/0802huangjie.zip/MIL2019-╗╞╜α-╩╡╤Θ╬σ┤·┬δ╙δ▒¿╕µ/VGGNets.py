import torch
import torch.nn as nn
import torchvision as tv
import torchvision.transforms as transforms
import torch.optim as optim

cfg = {
     'VGG11': [64, 'M', 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
     'VGG13': [64, 64, 'M', 128, 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
     'VGG16': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 'M', 512, 512, 512, 'M', 512, 512, 512, 'M'],
     'VGG19': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 256, 'M', 512, 512, 512, 512, 'M', 512, 512, 512, 512, 'M'],
}

# 定义是否使用GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class VGG(nn.Module):
    # 初始化参数
    def __init__(self,vgg_name):
        super(VGG,self).__init__()
        self.features = self._make_layers(cfg[vgg_name])
        self.classifier = nn.Linear(512,10)

    # 前向传播
    def forward(self,x):
        out = self.features(x)
        out = out.view(out.size(0),-1)
        out = self.classifier(out)
        return out

    def _make_layers(self,cfg):
        layers = []
        in_channels = 1
        for x in cfg:
            if x == 'M':
                layers += [nn.MaxPool2d(kernel_size=2, stride=2)]
            else:
                layers += [nn.Conv2d(in_channels, x, kernel_size=3, padding=1),
                           nn.BatchNorm2d(x),
                           nn.ReLU(inplace=True)]
                in_channels = x
        layers += [nn.AvgPool2d(kernel_size=1,stride=1)]
        return nn.Sequential(*layers)

# 超参数设置
EPOCH = 8  # 遍历训练整个数据集的次数
BATCH_SIZE = 60      # 批处理尺寸(batch_size),指将数据集分成n个batch(批)，每一个batch的大小
LR = 0.001        # 学习率

# 定义数据预处理方式
transform = transforms.ToTensor()

# 定义训练数据集
trainset = tv.datasets.MNIST(
    root='./data/',
    train=True,  # train=True表示训练集，train=False表示测试集
    download=True,
    transform=transform
)

# 定义训练批处理数据
# 数据加载器。组合数据集和采样器，并在数据集上提供单进程或多进程迭代器
trainloader = torch.utils.data.DataLoader(
    trainset,
    batch_size=BATCH_SIZE,  # 每个batch加载多少个样本
    shuffle=True,  # 设置为True时会在每个epoch重新打乱数据(默认: False)
)

# 定义测试数据集
testset = tv.datasets.MNIST(
    root='./data/',
    train=False,
    download=True,
    transform=transform
)

# 定义测试批处理数据
testloader = torch.utils.data.DataLoader(
    testset,
    batch_size=BATCH_SIZE,
    shuffle=False,
)

# 定义损失函数loss function 和优化方式（采用SGD）
net = VGG('VGG11').to(device)
criterion = nn.CrossEntropyLoss()  # 针对单目标分类问题, 结合了 nn.LogSoftmax() 和 nn.NLLLoss() 来计算 loss.
optimizer = optim.SGD(net.parameters(), lr=LR, momentum=0.9)  # 优化器，设置学习的速度和使用的模型

# 训练
if __name__ == "__main__":

    for epoch in range(EPOCH):
        sum_loss = 0.0
        # 数据读取
        for i, data in enumerate(trainloader):
            inputs, labels = data
            inputs, labels = inputs.to(device), labels.to(device)

            # 梯度清零，也就是把loss关于weight的导数变成0.
            optimizer.zero_grad()

            # 向后传播
            outputs = net(inputs)  # 网络的前向传播
            loss = criterion(outputs, labels)  # 将输出的outputs和原来导入的labels作为loss函数的输入，得到损失
            loss.backward()  # 计算得到loss后回传损失
            optimizer.step()  # 回传损失过程中会计算梯度，然后需要根据这些梯度更新参数，optimizer.step()就是用来更新参数的,进行单次优化

            # 每训练100个batch打印一次平均loss
            sum_loss += loss.item()
            if i % 100 == 99:
                print('[%d, %d] loss: %.03f'
                      % (epoch + 1, i + 1, sum_loss / 100))
                sum_loss = 0.0

        # 测试这个模型，每遍历一次测试一下准确率
        with torch.no_grad():
            correct = 0
            total = 0
            for data in testloader:
                images, labels = data
                images, labels = images.to(device), labels.to(device)
                outputs = net(images)
                # 取得分最高的那个类
                _, predicted = torch.max(outputs.data, 1)  # 预测最大值所在的位置标签，即预测的数字
                total += labels.size(0)
                correct += (predicted == labels).sum()
            print('第%d次遍历的识别准确率为：%d%%' % (epoch + 1, (100 * correct / total)))
## 作业终稿

### LSTM
数据集采用的是一个大量的英法翻译组成对
文件夹只包含一个lstm.py文件. 
其中主要工作为数据读取以及格式的转换，EncoderRNN类用于编码，DecoderRNN类用于解码，train以及evaluate用于训练以及测试.

### DCGAN
dcgan.py为整个dcgan框架对mnist数据集的生成，包含图像预处理，生成器与判别器，训练和测试的整个流程。

### CycleGAN 
文件夹包含utils.py,datasets.py,models.py,train.py,test.py五个文件，其中，utils.py封装了一些所需的函数，包括初始化权重，tensor2image，缓存区设置等。datasets.py文件为图像的处理。models.py为生成器和判别器的编码。train.py是整个训练过程。test.py为测试。

### CycleGANppt
谈论课ppt
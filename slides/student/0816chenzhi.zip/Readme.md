
# 实验七代码与报告
本次作业为GAN的实现
## 数据集：
mnist数据集；
## 文件分布
dcgan的实现文件是：dcgan.py文件

本周讨论课ppt：pix2pix.pptx文件


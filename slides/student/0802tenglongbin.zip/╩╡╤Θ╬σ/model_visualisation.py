import torch
import torch.nn as nn
from torch.utils.data.dataset import TensorDataset
from torch.utils.data.dataloader import DataLoader
from torch.autograd import Variable
import numpy as np
import cv2
import torchvision
import torchvision.transforms as transforms
from torchvision import models
import torch.utils.data as data
from PIL import Image
import os

def pil_loader(path):
    # open path as file to avoid ResourceWarning (https://github.com/python-pillow/Pillow/issues/835)
    with open(path, 'rb') as f:
        img = Image.open(f)
        return img.convert('RGB')

def accimage_loader(path):
    import accimage
    try:
        return accimage.Image(path)
    except IOError:
        # Potentially a decoding problem, fall back to PIL.Image
        return pil_loader(path)

def default_loader(path):
    from torchvision import get_image_backend
    if get_image_backend() == 'accimage':
        return accimage_loader(path)
    else:
        return pil_loader(path)

def has_file_allowed_extension(filename, extensions):
    """Checks if a file is an allowed extension.

    Args:
        filename (string): path to a file

    Returns:
        bool: True if the filename ends with a known image extension
    """
    filename_lower = filename.lower()
    return any(filename_lower.endswith(ext) for ext in extensions)

class CNN(nn.Module):

    def __init__(self, ):
        super(CNN, self).__init__()
        self.base = models.alexnet(pretrained=True)
        self.fc = nn.Linear(1000, 2)

    def forward(self, x):
        x = self.base(x)
        x = self.fc(x)
        return x


class DatasetFolder(data.Dataset):
    def __init__(self, root, transform, test=False):
        self.transform = transform
        if test:
            self.images, self.labels = self.make_dataset(root)
        else:
            self.images, self.labels = self.make_dataset(root)
    
    def __getitem__(self, index):
        path = self.images[index]
        label = self.labels[index]
        image = default_loader(path)
        image = self.transform(image)
        return image, label
    
    def __len__(self, ):
        return len(self.images)

    def make_dataset(self, root):
        images = []
        labels = []

        for rt, _, fnames in sorted(os.walk(root)):
            for fname in sorted(fnames):
                label = 0 if fname[0]=='c' else 1
                labels.append(label)
                path = os.path.join(rt, fname)
                images.append(path)
        return images, labels

class Trainer(object):

    def __init__(self, model, train_root, test_root, batch_size, shuffle, num_workers, learning_rate):
        transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5)),
        ])
        dataset = DatasetFolder(train_root, transform)
        self.len_train = len(dataset)
        self.dataloader_train = DataLoader(dataset=dataset, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
        dataset = DatasetFolder(test_root, transform, test=True)
        self.len_test = len(dataset)
        self.dataloader_test = DataLoader(dataset=dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)
        self.model = model 
        self.use_gpu = torch.cuda.is_available()
        self.loss_func = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=learning_rate)
        if self.use_gpu:
            self.model = self.model.cuda()

    def train(self, max_epoch, print_freq):
        """
        Args:
            max_epoch (int): train epoch.
            print_freq (int): the frequence of print.
        """
        for epoch in range(max_epoch):
            self.model.train()
            print('EPOCH[{:02d}/{:02d}]'.format(epoch + 1, max_epoch))
            print('#'*10, '-'*20, '#'*10)
            run_true = 0
            for i, (inputs, labels) in enumerate(self.dataloader_train):
                if self.use_gpu:
                    inputs, labels = inputs.cuda(), labels.cuda()
                outputs = self.model(inputs)
                loss = self.loss_func(outputs, labels)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                # statistic
                pred_true = torch.sum(torch.argmax(outputs, 1)==labels)
                run_true += pred_true
                if i % print_freq == 0:
                    acc = 100 * pred_true.item() / inputs.size(0)
                    print('[{:05d}/{:05d}] loss: {:.4f} acc: {:.2f}%'.format(i, self.len_train, loss.cpu().item(), acc)) 
            acc = 100 * run_true.item() / self.len_train
            print('EPOCH TRAIN ACCURACY: {:.2f}%'.format(acc))
            self.test()
            torch.save(self.model.state_dict(), 'saved_model_visualisation.pth')

    def test(self, ):
        self.model.eval()
        with torch.no_grad():
            run_true = 0
            for inputs, labels in self.dataloader_test:
                if self.use_gpu:
                    inputs, labels = inputs.cuda(), labels.cuda()
                outputs = self.model(inputs)
                pred_true = torch.sum(torch.argmax(outputs, 1)==labels)
                run_true += pred_true
            acc = 100 * run_true.item() / self.len_test
            print('EPOCH TEST ACCURACY: {:.2f}%'.format(acc))

def main():
    model = CNN()
    trainer = Trainer(
        model=model,
        train_root='I:/kaggle/train',
        test_root='I:/kaggle/test',
        batch_size=64, 
        shuffle=True, 
        num_workers=4, 
        learning_rate=2e-4
    )
    trainer.train(max_epoch=5, print_freq=100)

def class_model_visualisation(C):
    model = CNN()
    model.load_state_dict(torch.load('saved_model_visualisation.pth'))

    # different parameters have different effects
    LAMBDA = 1e-4
    LR = 10
    ITER_NUM = 10
    
    x = Variable(torch.zeros(1, 3, 224, 224), requires_grad=True)
    optimizer = torch.optim.Adam([{'params': x, 'lr': LR}], lr=LR)
    for i in range(ITER_NUM):        
        scores = model(x)
        # softmax
        # sm = nn.Softmax()
        # scores = sm(scores)
        score = scores[0, C]
        loss = -score + LAMBDA * torch.norm(x, 2)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if (i+1)%10 == 0:
            im = x.view(3, 224, 224).permute(1, 2, 0).detach().numpy()
            cv2.imwrite("img/class_%d_%d.jpg"%(C, i), im)

def class_saliency_visualisation(path, C):
    model = CNN()
    model.load_state_dict(torch.load('saved_model_visualisation.pth'))
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5)),
    ])
    transform2 = transforms.Compose([
        transforms.Resize((224, 224)), 
        transforms.ToTensor()
    ])
    image = default_loader(path)
    image = transform2(image)
    cv2.imwrite("img/src_"+path.split('/')[-1], image.permute(1, 2, 0).numpy()*255)
    image = default_loader(path)
    image = transform(image)
    image = image.view(1, 3, 224, 224)
    image = Variable(image, requires_grad=True)
    scores = model(image)
    score = scores[0, C]
    loss = -score
    loss.backward()
    im_grad = image.grad

    im_saliency = torch.max(torch.abs(im_grad[0]), 0)[0].view(-1)

    val, index = torch.sort(im_saliency)
    pixel_num = 224*224
    l1 = int(pixel_num*0.3)
    l2 = int(pixel_num*0.95)
    im_saliency[index[:l1]] = 0
    im_saliency[index[l1:l2]] = 122
    im_saliency[index[l2:]] = 255
    im_saliency = im_saliency.view(224, 224, 1).detach().numpy()
    cv2.imwrite("img/saliency_"+path.split('/')[-1], im_saliency)

if __name__ == "__main__":
    main()
    for i in range(2):
        class_model_visualisation(i)
    class_saliency_visualisation('I:/kaggle/train/cat.2504.jpg', 0)

# 入门实战卷积神经网络

## test_cnn.py
基于Pytorch框架，使用两层卷积神经网络实现MNIST分类

## compare_cnn.py
用torchvision.models中的alexnet、resnet18、squeezenet1_1、densenet121比较不同网络在相同参数下的性能。

### 训练参数

num_workers: 8

batch_size: 32

epoch: 20

learning_rate: 1e-3

### 数据集
CIFAR-100, label取其中20个超类

### 典型CNN性能比较

![](img/cnn_compare.jpg)

| CNN | 训练准确率(%) | 测试准确率(%) | 模型大小(M) | 训练时间(s) |
| ------ | ------ | ------ | ------ | ------ |
| alexnet | 32.9 | 34.6 | 233 | 4029|
| resnet18 | 96.8 | 65.0 | 44.7 | 3544 |
| squeezenet | 54.4 | 48.5 | 4.8 | 1825 |
| densenet121 | 91.4 | 64.5 | 30.9 |10995 |

## model_visualisation.py

实现论文 __Deep Inside Convolutional Networks: Visualising Image Classification Models and Saliency Maps__ 中的类模型可视化以及特定图像类显著可视化

类模型可视化如下图：

![](img/class_model_visualisation.jpg)

特定图像类显著可视化如下图：

![](img/class_saliency_visualisation.jpg)

## 论文分享.pdf

本周演讲演讲内容
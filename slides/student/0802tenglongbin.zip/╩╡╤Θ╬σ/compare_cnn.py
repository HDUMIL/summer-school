import torch 
import torch.nn as nn
from torchvision import models
import torchvision.transforms as transforms
from torch.utils.data.dataloader import DataLoader
import torch.utils.data as data

class CNN(nn.Module):

    def __init__(self, model_name):
        super(CNN, self).__init__()
        try:
            self.base_model = getattr(models, model_name)()
        except: 
            print('dont have model ', model_name)
        
        self.fc = nn.Linear(1000, 20)

    def forward(self, x):
        return self.fc(self.base_model(x))

def unpickle(file):
    import pickle
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict

class DatasetFolder(data.Dataset):
    def __init__(self, root):
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5)),
        ])
        data = unpickle(root)
        n = data[b'data'].shape[0]
        self.images = data[b'data'].reshape(n, 3, 32, 32).transpose((0, 2, 3, 1))
        self.labels = data[b'coarse_labels']
    
    def __getitem__(self, index):
        image = self.images[index]
        label = self.labels[index]
        image = self.transform(image)
        return image, label
    
    def __len__(self, ):
        return len(self.images)

class Trainer(object):

    def __init__(self, model, model_name, train_root, test_root, num_workers, batch_size, epoch, learning_rate):
        dataset_train = DatasetFolder(train_root)
        dataset_test = DatasetFolder(test_root)
        self.dataloader_train = DataLoader(dataset=dataset_train, batch_size=batch_size, shuffle=True, num_workers=num_workers)
        self.dataloader_test = DataLoader(dataset=dataset_test, batch_size=batch_size, shuffle=False, num_workers=num_workers)
        self.len_train = len(dataset_train)
        self.len_test = len(dataset_test)
        self.model = model
        self.model_name = model_name
        self.use_gpu = torch.cuda.is_available()
        self.loss_func = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.SGD(self.model.parameters(), lr=learning_rate)
        self.epoch = epoch
        if self.use_gpu:
            self.model = self.model.cuda()

    def train(self, print_freq=100):
        train_acc = []
        test_acc = []
        for epoch in range(self.epoch):
            self.model.train()
            print('EPOCH[{:02d}/{:02d}]'.format(epoch + 1, self.epoch))
            print('#'*10, '-'*20, '#'*10)
            run_true = 0
            cnt = 0
            for i, (inputs, labels) in enumerate(self.dataloader_train):
                cnt += inputs.size(0)
                if self.use_gpu:
                    inputs, labels = inputs.cuda(), labels.cuda()
                outputs = self.model(inputs)
                loss = self.loss_func(outputs, labels)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                # statistic
                pred_true = torch.sum(torch.argmax(outputs, 1)==labels)
                run_true += pred_true
                if i % print_freq == 0:
                    acc = 100 * pred_true.item() / inputs.size(0)
                    print('[{:05d}/{:05d}] loss: {:.4f} acc: {:.2f}%'.format(cnt, self.len_train, loss.cpu().item(), acc))
            acc = 100 * run_true.item() / self.len_train
            print('EPOCH TRAIN ACCURACY: {:.2f}%'.format(acc))
            train_acc.append(acc)
            test_acc.append(self.test())
        torch.save(self.model.state_dict(), self.model_name+'.pth')
        return train_acc, test_acc

    def test(self, ):
        self.model.eval()
        with torch.no_grad():
            run_true = 0
            for inputs, labels in self.dataloader_test:
                if self.use_gpu:
                    inputs, labels = inputs.cuda(), labels.cuda()
                outputs = self.model(inputs)
                pred_true = torch.sum(torch.argmax(outputs, 1)==labels)
                run_true += pred_true
            acc = 100 * run_true.item() / self.len_test
            print('EPOCH TEST ACCURACY: {:.2f}%'.format(acc))
            return acc

model_name = [
    'alexnet',
    'resnet18',
    'squeezenet1_1',
    'densenet121',
]
statistic = {}
import time
def main():
    for name in model_name:
        st = time.time()
        model = CNN(name)
        trainer = Trainer(
            model=model, 
            model_name=name, 
            train_root='cifar100/train',
            test_root='cifar100/test',
            num_workers=8,
            batch_size=32,
            epoch=20,
            learning_rate=1e-3
        )
        train_acc, test_acc = trainer.train()
        statistic[name] = {'train_acc':train_acc, 'test_acc':test_acc, 'time':time.time()-st}
        f = open('dict', 'w')
        f.write(str(statistic))
        f.close()
        print(statistic)
        torch.cuda.empty_cache()
    print(statistic)

if __name__ == "__main__":
    main()


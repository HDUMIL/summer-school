import torch
import torch.nn as nn
from sklearn.datasets import fetch_mldata
from torch.utils.data.dataset import TensorDataset
from torch.utils.data.dataloader import DataLoader
from torch.optim import lr_scheduler
import numpy as np
import warnings
warnings.filterwarnings("ignore")

class CNN(nn.Module):

    def __init__(self, ):
        super(CNN, self).__init__()
        self.feature = nn.Sequential(
            nn.Conv2d(1, 16, 4, 1), # 3, 25, 25
            nn.MaxPool2d(3, 2),  # 16, 12, 12
            nn.BatchNorm2d(16),
            nn.ReLU(), 
            nn.Conv2d(16, 32, 3, 2, 1), # 32, 6, 6
            nn.AvgPool2d(3, 2, 1), # 32, 3, 3
            nn.BatchNorm2d(32),
            nn.ReLU(),
        )
        self.fc = nn.Linear(32*3*3, 10)
    
    def forward(self, x):
        x = self.feature(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

class Trainer(object):

    def __init__(self, model, batch_size, shuffle, num_workers, learning_rate):
        mnist = fetch_mldata('MNIST Original', data_home='./')
        self.len_train = 60000
        self.len_test = 10000
        shuffle_index = np.array(range(mnist.data.shape[0]))
        np.random.shuffle(shuffle_index)
        mnist.data = mnist.data[shuffle_index]
        mnist.target = mnist.target[shuffle_index]
        dataset = TensorDataset(torch.from_numpy(mnist.data[:self.len_train]).float(), torch.from_numpy(mnist.target[:self.len_train]).long())
        self.dataloader = DataLoader(dataset=dataset, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
        dataset = TensorDataset(torch.from_numpy(mnist.data[self.len_train:]).float(), torch.from_numpy(mnist.target[self.len_train:]).long())
        self.dataloader_test = DataLoader(dataset=dataset, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
        self.model = model 
        self.use_gpu = torch.cuda.is_available()
        self.loss_func = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=learning_rate)
        if self.use_gpu:
            self.model = self.model.cuda()

    def train(self, max_epoch, print_freq, decay_epoch):
        """
        Parameters:
            print_freq : int, the frequence of print.
            decay_epoch : int, decays the learning rate by 0.1 every decay_epoch. 
        """
        scheduler = lr_scheduler.StepLR(self.optimizer, step_size=decay_epoch, gamma=0.1)
        for epoch in range(max_epoch):
            self.model.train()
            scheduler.step()
            print('EPOCH[{:02d}/{:02d}]'.format(epoch + 1, max_epoch))
            print('#'*10, '-'*20, '#'*10)
            run_true = 0
            for i, (inputs, labels) in enumerate(self.dataloader):
                if self.use_gpu:
                    inputs, labels = inputs.cuda(), labels.cuda()
                    inputs = inputs.view(inputs.size(0), 1, 28, 28)
                outputs = self.model(inputs)
                loss = self.loss_func(outputs, labels)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                # statistic
                pred_true = torch.sum(torch.argmax(outputs, 1)==labels)
                run_true += pred_true
                if i % print_freq == 0:
                    acc = 100 * pred_true.item() / inputs.size(0)
                    print('[{:05d}/{:05d}] loss: {:.4f} acc: {:.2f}%'.format(i, len(self.dataloader), loss.cpu().item(), acc)) 
            acc = 100 * run_true.item() / self.len_train
            print('EPOCH TRAIN ACCURACY: {:.2f}%'.format(acc))
            self.test()

    def test(self, ):
        self.model.eval()
        with torch.no_grad():
            run_true = 0
            for inputs, labels in self.dataloader_test:
                if self.use_gpu:
                    inputs, labels = inputs.cuda(), labels.cuda()
                    inputs = inputs.view(inputs.size(0), 1, 28, 28)
                outputs = self.model(inputs)
                pred_true = torch.sum(torch.argmax(outputs, 1)==labels)
                run_true += pred_true
            acc = 100 * run_true.item() / self.len_test
            print('EPOCH TEST ACCURACY: {:.2f}%'.format(acc))


def main():
    model = CNN()
    trainer = Trainer(
        model=model, 
        batch_size=128, 
        shuffle=True, 
        num_workers=4, 
        learning_rate=1e-4
    )
    trainer.train(max_epoch=40, print_freq=100, decay_epoch=20)
    # TRAIN ACCURACY: 98.58%
    # TEST ACCURACY: 98.22%

if __name__ == "__main__":
    main()

import argparse
import os
import torch
import torch.nn as nn
from tensorboardX import SummaryWriter
import torchvision.datasets as dset
import torchvision.transforms as transforms
import torchvision.utils as vutils
from LSGAN.model import generator
from LSGAN.model import discriminator
from torch.utils.data import DataLoader

parser = argparse.ArgumentParser()
parser.add_argument('--data_path', default='./data', help='which dataset to train on')
parser.add_argument('--batch_size', type=int, default=24, help='input of batch size')
parser.add_argument('--image_size', type=int, default=64, help='the weight and height of input image')
parser.add_argument('--nz', type=int, default=100, help='size of the latent z vector')
parser.add_argument('--nc', type=int, default=3, help='the channel of input image')
parser.add_argument('--workers', type=int, default=8, help='number of data loading workers')
parser.add_argument('--ngf', type=int, default=64)
parser.add_argument('--ndf', type=int, default=64)
parser.add_argument('--niter', type=int, default=300000, help='number of iterations to train for')
parser.add_argument('--lr', type=float, default=0.0001, help='learning rate, default=0.0002')
parser.add_argument('--beta1', type=float, default=0.5, help='beta1 for adam. default=0.5')
parser.add_argument('--outf', default='image_LSUN/', help='folder to output images and model checkpoints')
parser.add_argument('--logs', default='logs_LSUN/', help='folder to logs')
opt = parser.parse_args()
device = torch.device('cuda:0')

try:
    os.makedirs(opt.outf)
    os.makedirs(opt.logs)
except OSError:
    pass

dataSet = dset.ImageFolder(opt.data_path, transform=transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.CenterCrop(opt.image_size),
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
]))

loader_ = DataLoader(dataset=dataSet, batch_size=opt.batch_size, shuffle=True, num_workers=8)

loader = iter(loader_)

def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find('BatchNorm') != -1:
        nn.init.normal_(m.weight.data, 1.0, 0.02)
        nn.init.constant_(m.bias.data, 0)

netG = generator(64)
netG.apply(weights_init)
netD = discriminator(64)
netD.apply(weights_init)
netG.cuda()
netD.cuda()

optimizerG = torch.optim.Adam(netG.parameters(), lr=opt.lr, betas=(opt.beta1, 0.99))
optimizerD = torch.optim.Adam(netD.parameters(), lr=opt.lr, betas=(opt.beta1, 0.99))

noise = torch.FloatTensor(opt.batch_size, opt.nz, 1, 1)
real = torch.FloatTensor(opt.batch_size, opt.nc, opt.image_size, opt.image_size)
label = torch.FloatTensor(1)

real_label = 1
fake_label = 0

noise.cuda()
real.cuda()
label.cuda()

write = SummaryWriter(log_dir='./logs_LSUN')

for iteration in range(1, opt.niter+1):
    try:
        images = loader.next()
    except:
        loader = iter(loader_)
        images = loader.next()
    images = images[0]
    netD.zero_grad()
    netG.zero_grad()
    real.resize_(images.size()).copy_(images)

    noise.resize_(opt.batch_size, opt.nz, 1, 1)
    noise.data.uniform_(-1, 1)

    noise = noise.to(device)
    real = real.to(device)
    fake = netG(noise)
    real_recons = netD(real)
    fake_recons = netD(fake.detach())

    err_real = 0.5*torch.mean((real_recons - 1)**2)
    err_fake = 0.5*torch.mean((fake_recons + 1)**2)
    errD = err_fake + err_real
    errD.backward()
    optimizerD.step()

    fake = netG(noise)
    fake_recons = netD(fake)
    errG = 0.5*torch.mean(fake_recons**2)
    errG.backward()
    optimizerG.step()

    write.add_scalar('err_fake', err_fake.item(), global_step=iteration)
    write.add_scalar('err_real', err_real.item(), global_step=iteration)
    write.add_scalar('errG', errG.item(), global_step=iteration)

    print('[%d/%d] Loss_D: %.4f Loss_G: %.4f'%(iteration, opt.niter,errD.item(), errG.item()))

    if(iteration % 1000 == 0):
        vutils.save_image(fake.data,
                    '%s/fake_samples_iteration_%03d.png' % (opt.outf, iteration),
                    normalize=True)
        vutils.save_image(real.data,
                    '%s/real_samples_iteration_%03d.png' % (opt.outf, iteration),
                    normalize=True)

    if(iteration % 10000 == 0):
        torch.save(netG.state_dict(), '%s/netG_%d.pth' % (opt.outf, iteration))
        torch.save(netD.state_dict(), '%s/netD_%d.pth' % (opt.outf, iteration))
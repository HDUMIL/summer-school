import torch
import torch.nn as nn
import torch.nn.functional as F

class generator(nn.Module):
    def __init__(self, d=64):
        super(generator, self).__init__()
        self.deconv1_1 = nn.ConvTranspose2d(100, d*4, 4, 1, 0)
        self.deconv1_1_bn = nn.BatchNorm2d(d*4)
        self.deconv1_2 = nn.ConvTranspose2d(2, d*4, 4, 1, 0)
        self.deconv1_2_bn = nn.BatchNorm2d(d*4)
        self.deconv2 = nn.ConvTranspose2d(d*8, d*4, 4, 2, 1)
        self.deconv2_bn = nn.BatchNorm2d(d*4)
        self.deconv3 = nn.ConvTranspose2d(d*4, d*2, 4, 2, 1)
        self.deconv3_bn = nn.BatchNorm2d(d*2)
        self.deconv4 = nn.ConvTranspose2d(d*2, d, 4, 2, 1)
        self.deconv4_bn = nn.BatchNorm2d(d)
        self.deconv5 = nn.ConvTranspose2d(d, 3, 4, 2, 1)

    def forward(self, input, label):
        input = input.view(-1, input.size(1), 1, 1)
        label = label.view(-1, label.size(1), 1, 1)
        x = F.leaky_relu(self.deconv1_1_bn(self.deconv1_1(input)), 0.2)
        y = F.leaky_relu(self.deconv1_2_bn(self.deconv1_2(label)), 0.2)
        x = torch.cat([x, y], 1)
        x = F.leaky_relu(self.deconv2_bn(self.deconv2(x)), 0.2)
        x = F.leaky_relu(self.deconv3_bn(self.deconv3(x)), 0.2)
        x = F.leaky_relu(self.deconv4_bn(self.deconv4(x)), 0.2)
        x = F.tanh(self.deconv5(x))
        return x

class discriminator(nn.Module):
    def __init__(self, d=64):
        super(discriminator, self).__init__()
        self.conv1_1 = nn.Conv2d(3, d//2, 4, 2, 1)
        self.conv1_2 = nn.Conv2d(2, d//2, 4, 2, 1)
        self.conv2 = nn.Conv2d(d, d*2, 4, 2, 1)
        self.conv2_bn = nn.BatchNorm2d(d*2)
        self.conv3 = nn.Conv2d(d*2, d*4, 4, 2, 1)
        self.conv3_bn = nn.BatchNorm2d(d*4)
        self.conv4 = nn.Conv2d(d*4, d*8, 4, 2, 1)
        self.conv4_bn = nn.BatchNorm2d(d*8)
        self.conv5 = nn.Conv2d(d*8, 1, 4, 1, 0)

    def forward(self, input, label):
        label = label.unsqueeze(2).repeat(1, 1, input.size(2) * input.size(2)).reshape(input.size(0), label.size(1), input.size(2), input.size(2))
        x = F.leaky_relu(self.conv1_1(input), 0.2)
        y = F.leaky_relu(self.conv1_2(label), 0.2)
        x = torch.cat([x, y], 1)
        x = F.leaky_relu(self.conv2_bn(self.conv2(x)), 0.2)
        x = F.leaky_relu(self.conv3_bn(self.conv3(x)), 0.2)
        x = F.leaky_relu(self.conv4_bn(self.conv4(x)), 0.2)
        x = self.conv5(x)
        # x = F.sigmoid(self.conv5(x))
        return x

if __name__ == '__main__':
    # y = torch.rand(2, 3)
    # print(y)
    # input = torch.rand(2, 3, 2, 2)
    # out = y.unsqueeze(2).repeat(1, 1, input.size(2) * input.size(2)).reshape(input.size(0), y.size(1), input.size(2), input.size(2))
    # print(out)
    G = generator(64)
    z = torch.rand(64, 100, 1, 1)
    print(z.size())
    label = torch.rand(64, 2)
    print(label.size())
    x = G(z, label)
    print(x.size())
    D = discriminator(64)
    img = torch.randn(64, 3, 64, 64)
    y = D(img, label)
    print(y.size())
    # a = [0, 2, 3, 4, 1, 0]
    # a = torch.Tensor(a).long()
    # # a = torch.LongTensor(6, 1).random_() % 5
    # a = torch.LongTensor(a).view(-1, 1)
    # print(a)
    # print(type(a))
    # a = torch.zeros(6, 5).scatter_(1, a, 1)
    # print(a)

import torch
import torch.nn as nn
from torch.autograd import Variable

class generator(nn.Module):
    def __init__(self, d=64):
        super(generator, self).__init__()
        self.main = nn.Sequential(
            nn.ConvTranspose2d(100, d*8, 4, 1, 0, bias=False),
            nn.BatchNorm2d(d*8),
            nn.ReLU(True),
            nn.ConvTranspose2d(d*8, d*4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(d*4),
            nn.ReLU(True),
            nn.ConvTranspose2d(d*4, d*2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(d*2),
            nn.ReLU(True),
            nn.ConvTranspose2d(d*2, d, 4, 2, 1, bias=False),
            nn.BatchNorm2d(d),
            nn.ReLU(True),
            nn.ConvTranspose2d(d, 3, 4, 2, 1, bias=False),
            nn.Tanh()
        )

    def forward(self, input, label):
        return self.main(input)

class discriminator(nn.Module):
    def __init__(self, d=64):
        super(generator, self).__init__()
        self.main = nn.Sequential(
            # input is (nc) x 64 x 64
            nn.Conv2d(3, d, 4, 2, 1),
            nn.LeakyReLU(0.2, inplace=True),
            # state size. (ndf) x 32 x 32
            nn.Conv2d(d, d * 2, 4, 2, 1),
            nn.BatchNorm2d(d * 2),
            nn.LeakyReLU(0.2, inplace=True),
            # state size. (ndf*2) x 16 x 16
            nn.Conv2d(d * 2, d * 4, 4, 2, 1),
            nn.BatchNorm2d(d * 4),
            nn.LeakyReLU(0.2, inplace=True),
            # state size. (ndf*4) x 8 x 8
            nn.Conv2d(d * 4, d * 8, 4, 2, 1),
            nn.BatchNorm2d(d * 8),
            nn.LeakyReLU(0.2, inplace=True),
            # state size. (ndf*8) x 4 x 4
            nn.Conv2d(d * 8, 1, 4, 1, 0),
        )

    def forward(self, input):
        return self.main(input)

if __name__ == '__main__':
    nz = 100
    netG = generator(64)
    netD = discriminator(64)
    noise = torch.randn(64, 100, 1, 1)
    noise = Variable(noise)
    image = torch.randn(64, 3, 64, 64)
    image = Variable(image)
    outputG = netG(noise)
    outputD = netD(image)
    print(outputD.shape)
    print(outputG.shape)

import torch
import torch.nn as nn
import numpy as np
import os
import scipy.misc
import torchvision

class Face():
    def __init__(self):
        self.channel = 3

    def load_data(self, image_path, output_size=64):
        self.output_size = output_size
        self.image_list, self.image_labels = load_image_data(image_path)
        self.shuffle_data()

    def shuffle_data(self):
        length = len(self.image_list)
        perm = np.arange(length)
        np.random.shuffle(perm)
        self.image_list = self.image_list[perm]
        self.image_labels = self.image_labels[perm]

    def get_batch_image(self, filenames, resize_w=64):
        array = [get_image(batch_file, resize_w=resize_w) for batch_file in filenames]
        sample_images = np.array(array, dtype=np.float32)
        return sample_images

    def get_next_batch(self, batch_num=0, batch_size=64):
        batch_img = self.image_list[batch_num*batch_size: (batch_num+1)*batch_size]
        batch_img = self.get_batch_image(batch_img, self.output_size)
        batch_img = batch_img.transpose([0, 3, 1, 2])
        batch_label = self.image_labels[batch_num*batch_size: (batch_num+1)*batch_size, :]
        return batch_img, batch_label

def get_image(image_path, resize_w=64):
    img = scipy.misc.imread(image_path).astype(np.float32, resize_w)
    img = scipy.misc.imresize(img, [resize_w, resize_w])
    return np.array(img) / 127.5 - 1.0

def load_image_data(image_path):
    filenames = []
    labels = []
    file = open(image_path, 'r')
    file = file.readlines()
    for line in file:
        items = line.split(' ')
        data_path = items[0]
        filenames.append(data_path)
        ethic = np.int32(items[2])
        sex = np.int32(items[3])
        age = np.int32(items[4])
        labels.append([ethic, sex, age])
    filenames = np.array(filenames)
    labels = np.array(labels)

    return filenames, labels

def get_sample_image(G, n_noise,num_classes, device, outfile):
    display_size = 8
    y = torch.zeros([display_size*num_classes, num_classes]).to(device)
    for i in range(num_classes):
        y[i*display_size:(i+1)*display_size,i] = 1.0
    z = torch.randn(display_size*num_classes, n_noise).to(device)
    G.eval()
    imgs = G(z, y)
    imgs = imgs / 2 + 0.5
    imgs = torchvision.utils.make_grid(imgs)
    torchvision.utils.save_image(imgs, outfile, nrow=display_size)

if __name__ == '__main__':
    data = Face()
    data.load_data('./trainImgpath.txt')
    imgs, label = data.get_next_batch()
    print(len(data.image_list))
    print(imgs.shape)

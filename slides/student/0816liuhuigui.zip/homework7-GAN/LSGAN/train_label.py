import argparse
import os
import torch
import torch.nn as nn
from tensorboardX import SummaryWriter
import torchvision.utils as vutils
from LSGAN.model_labels import generator
from LSGAN.model_labels import discriminator
from LSGAN.utils import *

parser = argparse.ArgumentParser()
parser.add_argument('--data_path', default='./label_train-finish.txt', help='which dataset to train on')
parser.add_argument('--batch_size', type=int, default=64, help='input of batch size')
parser.add_argument('--image_size', type=int, default=64, help='the weight and height of input image')
parser.add_argument('--nz', type=int, default=100, help='size of the latent z vector')
parser.add_argument('--nc', type=int, default=3, help='the channel of input image')
parser.add_argument('--workers', type=int, default=8, help='number of data loading workers')
parser.add_argument('--ngf', type=int, default=64)
parser.add_argument('--ndf', type=int, default=64)
parser.add_argument('--niter', type=int, default=400000, help='number of iterations to train for')
parser.add_argument('--lr', type=float, default=0.0001, help='learning rate, default=0.0002')
parser.add_argument('--beta1', type=float, default=0.5, help='beta1 for adam. default=0.5')
parser.add_argument('--outf', default='image_label/', help='folder to output images and model checkpoints')
parser.add_argument('--logs', default='logs_label/', help='folder to logs')
opt = parser.parse_args()
device = torch.device('cuda:0')

try:
    os.makedirs(opt.outf)
    os.makedirs(opt.logs)
except OSError:
    pass

def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find('BatchNorm') != -1:
        nn.init.normal_(m.weight.data, 1.0, 0.02)
        nn.init.constant_(m.bias.data, 0)

netG = generator(64)
# netG.apply(weights_init)
netD = discriminator(64)
# netD.apply(weights_init)
netG.cuda()
netD.cuda()
netG.load_state_dict(torch.load('./image_label/netG_310000.pth'))
netD.load_state_dict(torch.load('./image_label/netD_310000.pth'))

optimizerG = torch.optim.Adam(netG.parameters(), lr=opt.lr, betas=(opt.beta1, 0.99))
optimizerD = torch.optim.Adam(netD.parameters(), lr=opt.lr, betas=(opt.beta1, 0.99))

noise = torch.FloatTensor(opt.batch_size, opt.nz, 1, 1)
real = torch.FloatTensor(opt.batch_size, opt.nc, opt.image_size, opt.image_size)
label = torch.FloatTensor(1)

real_label = 1
fake_label = 0

noise.cuda()
real.cuda()
label.cuda()

write = SummaryWriter(log_dir='./logs_label')
criterion = nn.BCELoss()

data = Face()
data.load_data(opt.data_path)
batch_num = -1
length = len(data.image_list)
ro_num = length // opt.batch_size
for iteration in range(310000, opt.niter+1):
    batch_num = (batch_num+1) % ro_num
    image, labels = data.get_next_batch(batch_num, opt.batch_size)
    labels_race = []
    labels_gender = []
    labels_age = []
    for i in range(labels.shape[0]):
        labels_race.append(labels[i][0])
        labels_gender.append(labels[i][1])
        labels_age.append(labels[i][2])
    labels_race = torch.LongTensor(labels_race).view(-1, 1)
    labels_gender = torch.LongTensor(labels_gender).view(-1, 1)
    labels_age = torch.LongTensor(labels_age).view(-1, 1)
    labels_race = torch.zeros(labels_race.size(0), 5).scatter_(1, labels_race, 1).to(device)
    labels_gender = torch.zeros(labels_gender.size(0), 2).scatter_(1, labels_gender, 1).to(device)
    labels_age = torch.zeros(opt.batch_size, 2).scatter_(1, labels_age, 1).to(device)

    netD.zero_grad()
    netG.zero_grad()
    image = torch.from_numpy(image)
    real.resize_(image.size()).copy_(image)

    noise.resize_(opt.batch_size, opt.nz, 1, 1)
    noise.data.uniform_(-1, 1)

    noise = noise.to(device)
    real = real.to(device)
    fake = netG(noise, labels_gender)
    real_recons = netD(real, labels_gender)
    fake_recons = netD(fake.detach(), labels_gender)

    errD_real = 0.5*torch.mean((real_recons - 1)**2)
    errD_fake = 0.5*torch.mean((fake_recons + 1)**2)
    errD = errD_fake + errD_real
    errD.backward()
    optimizerD.step()

    fake = netG(noise, labels_gender)
    fake_recons = netD(fake, labels_gender)
    errG = 0.5*torch.mean(fake_recons**2)
    errG.backward()
    optimizerG.step()

    write.add_scalar('err_fake', errD_fake.item(), global_step=iteration)
    write.add_scalar('err_real', errD_real.item(), global_step=iteration)
    write.add_scalar('errG', errG.item(), global_step=iteration)

    print('[%d/%d] Loss_D: %.4f Loss_G: %.4f'%(iteration, opt.niter,errD.item(), errG.item()))

    if(iteration % 1000 == 0):
        get_sample_image(netG, n_noise=100, num_classes=2, device=device,
            outfile=os.path.join('image_label', '{}.png'.format(iteration)))

    if(iteration % 10000 == 0):
        torch.save(netG.state_dict(), '%s/netG_%d.pth' % (opt.outf, iteration))
        torch.save(netD.state_dict(), '%s/netD_%d.pth' % (opt.outf, iteration))
## GAN

- LSGAN.md 关于LSGAN的笔记
- LSGAN文件夹：复现LSGAN论文
  - 模型采用DCGAN网络模型
  - 训练数据集使用vggface2
  - 两组实验：无标签数据和有标签数据（性别标签）
  - 训练迭代次数：300K
WGAN文件 为 WGAN 的实现代码
图片为 WGAN epoch=1000时的效果